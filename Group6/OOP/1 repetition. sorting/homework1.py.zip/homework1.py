car = {
  'mark': 'volvo',
  'model': 's60',
  'year': 2016,
}
car['color'] = 'black'
print(car['mark'])

fruits = ['plum', 'melon', 'watermelon', 'peach']
print(fruits[0])

numbers = (1, 4, 55, 67)
print(numbers[-1])